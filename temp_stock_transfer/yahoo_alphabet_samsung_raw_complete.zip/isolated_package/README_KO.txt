RAW 열: Date, Open, High, Low, Close, Adj Close, Volume
GOOGL=알파벳 A주, GOOG=알파벳 C주, 005930.KS=삼성전자, YHOO=구 야후
보간·단위변경 없음.
